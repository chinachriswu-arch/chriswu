import SwiftUI
import UIKit

private let forest = Color(red: 0.14, green: 0.34, blue: 0.26)

struct ContentView: View {
    @ObservedObject var model: MonitorModel
    @State private var showAdd = false
    @State private var showHelp = false
    @State private var reconnecting: StoredAccount?
    @State private var renaming: StoredAccount?
    @State private var deleting: StoredAccount?
    @State private var alias = ""
    @State private var search = ""
    private var filtered: [StoredAccount] {
        model.accounts.filter { search.isEmpty || ($0.alias + " " + ($0.email ?? "")).localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    HStack {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("已连接账号").font(.subheadline).foregroundStyle(.white.opacity(0.75))
                            Text("\(model.accounts.count)").font(.system(size: 48, weight: .medium, design: .rounded))
                            Text("Codex 额度 · 设备直连查询").font(.caption).foregroundStyle(.white.opacity(0.8))
                        }
                        Spacer()
                        Image(systemName: "chart.bar.xaxis").font(.system(size: 46, weight: .ultraLight)).opacity(0.5)
                    }
                    .foregroundStyle(.white).padding(24).background(forest, in: RoundedRectangle(cornerRadius: 26))

                    Label("GPT 聊天次数不等于 Codex 额度。Plus 标识只表示查询返回的套餐，不代表续费或到期日期。", systemImage: "info.circle")
                        .font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)

                    HStack {
                        Text("我的账号").font(.title3.bold())
                        Spacer()
                        if model.busy { ProgressView() }
                        Button { Task { await model.refreshAll() } } label: {
                            Image(systemName: "arrow.clockwise").padding(8)
                        }.disabled(model.busy || model.connecting || model.vaultUnavailable)
                            .accessibilityLabel("刷新所有账号")
                    }
                    if model.accounts.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "person.crop.circle.badge.plus").font(.system(size: 42)).foregroundStyle(forest)
                            Text("连接你的第一个账号").font(.headline)
                            Text("在官方页面完成授权后，查询真实额度。\n不需要向本工具提供密码或 2FA 密钥。")
                                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                            Button("连接 ChatGPT / Codex") { showAdd = true }.buttonStyle(.borderedProminent)
                                .disabled(model.vaultUnavailable)
                        }.frame(maxWidth: .infinity).padding(.vertical, 32).card()
                    }
                    ForEach(filtered) { account in
                        AccountCard(account: account, onReconnect: { reconnecting = account },
                            onRename: { alias = account.alias; renaming = account }, onDelete: { deleting = account })
                            .disabled(model.busy || model.connecting)
                    }
                    if !model.accounts.isEmpty && filtered.isEmpty {
                        Text("没有匹配的账号").foregroundStyle(.secondary).frame(maxWidth: .infinity).padding()
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        Label("仅保存在这台 iPhone 的钥匙串", systemImage: "lock.shield")
                        Text("前台每 2 分钟刷新；后台不保证持续查询。到达重置时间后会提示核对，绝不自动把额度改成满额。")
                        Text("独立实验项目 · 非 OpenAI 官方产品")
                    }.font(.caption).foregroundStyle(.secondary).padding(.vertical, 8)
                }.padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("额度口袋").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "搜索账号")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }.accessibilityLabel("使用帮助")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                        .disabled(model.busy || model.connecting || model.vaultUnavailable).accessibilityLabel("添加账号")
                }
            }
            .refreshable { await model.refreshAll() }
            .sheet(isPresented: $showAdd, onDismiss: model.cancelLogin) {
                LoginView(model: model, replacing: nil)
            }
            .sheet(item: $reconnecting, onDismiss: model.cancelLogin) { account in
                LoginView(model: model, replacing: account)
            }
            .sheet(isPresented: $showHelp) { HelpView(model: model) }
            .alert("修改账号名称", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("名称", text: $alias)
                Button("保存") { if let account = renaming { model.rename(account.id, alias: String(alias.prefix(80))) }; renaming = nil }
                Button("取消", role: .cancel) { renaming = nil }
            }
            .confirmationDialog("从本机删除账号及其登录凭据？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                Button("删除本机账号", role: .destructive) { if let account = deleting { model.remove(account.id) }; deleting = nil }
            } message: { Text("不删除你的 OpenAI 账号，不取消订阅。删除后可重新授权连接。") }
            .alert("提示", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
                Button("知道了") { model.message = nil }
            } message: { Text(model.message ?? "") }
        }
    }
    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("YOUR LIMITS, IN VIEW").font(.caption2.weight(.semibold)).tracking(2).foregroundStyle(.secondary)
            Text("每一份额度，心里有数。").font(.title2.bold())
        }.padding(.top, 8)
    }
}

struct AccountCard: View {
    let account: StoredAccount
    let onReconnect: () -> Void
    let onRename: () -> Void
    let onDelete: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(account.alias).font(.headline)
                    if let email = account.email { Text(email).font(.caption).foregroundStyle(.secondary).textSelection(.enabled) }
                }
                Spacer(minLength: 8)
                Text(account.snapshot?.payload.planLabel ?? "未知")
                    .font(.caption.weight(.semibold)).padding(.horizontal, 10).padding(.vertical, 6)
                    .background(forest.opacity(0.10), in: Capsule())
                Menu {
                    Button("重新授权", systemImage: "arrow.triangle.2.circlepath", action: onReconnect)
                    Button("修改名称", systemImage: "pencil", action: onRename)
                    Button("删除本机账号", systemImage: "trash", role: .destructive, action: onDelete)
                } label: { Image(systemName: "ellipsis").padding(8) }.accessibilityLabel("账号操作")
            }
            if let snapshot = account.snapshot {
                TimelineView(.periodic(from: .now, by: 30)) { context in
                    VStack(alignment: .leading, spacing: 14) {
                        Text(snapshot.payload.plusStatus).font(.caption).foregroundStyle(.secondary)
                        if snapshot.payload.rateLimit?.allowed == false {
                            Label("官方返回：当前常规额度不可用", systemImage: "exclamationmark.circle")
                                .font(.caption).foregroundStyle(.orange)
                        }
                        if let group = snapshot.payload.rateLimit, !group.windows.isEmpty {
                            ForEach(Array(group.windows.enumerated()), id: \.offset) { _, window in
                                WindowRow(window: window, snapshot: snapshot, now: context.date)
                            }
                        } else {
                            Text("常规额度：未知（响应未提供）").font(.subheadline).foregroundStyle(.secondary)
                        }
                        ForEach(Array((snapshot.payload.additionalRateLimits ?? []).enumerated()), id: \.offset) { _, extra in
                            if let group = extra.rateLimit, !group.windows.isEmpty {
                                Text(extra.limitName ?? extra.meteredFeature ?? "附加额度").font(.caption.bold())
                                ForEach(Array(group.windows.enumerated()), id: \.offset) { _, window in
                                    WindowRow(window: window, snapshot: snapshot, now: context.date)
                                }
                            }
                        }
                        HStack(spacing: 4) {
                            Image(systemName: snapshot.isStale(at: context.date) || account.lastError != nil ? "clock" : "checkmark.circle")
                            Text("上次成功 \(snapshot.observedAt.formatted(date: .abbreviated, time: .shortened))")
                            if snapshot.isStale(at: context.date) || account.lastError != nil { Text("· 缓存值") }
                        }.font(.caption2).foregroundStyle(.secondary)
                        Text("订阅到期日：未知（此额度接口不提供）").font(.caption2).foregroundStyle(.secondary)
                    }
                }
            } else {
                Text("尚未成功读取额度和套餐状态").font(.subheadline).foregroundStyle(.secondary)
            }
            if let error = account.lastError {
                Label(error, systemImage: "exclamationmark.triangle").font(.caption).foregroundStyle(.orange)
            }
        }.padding(18).card()
    }
}

struct WindowRow: View {
    let window: UsageWindow
    let snapshot: UsageSnapshot
    let now: Date
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(window.title).font(.subheadline)
                Spacer()
                if let remaining = window.remaining {
                    Text("剩余 \(remaining.formatted(.number.precision(.fractionLength(0...1))))%")
                        .font(.subheadline.weight(.semibold)).monospacedDigit()
                } else { Text("未知").foregroundStyle(.secondary) }
            }
            if let remaining = window.remaining {
                ProgressView(value: remaining, total: 100).tint(remaining < 20 ? .orange : forest)
            }
            if let reset = window.resetDate(observedAt: snapshot.observedAt) {
                if reset <= now {
                    Text("已到预计重置时间，请刷新核对").font(.caption).foregroundStyle(.orange)
                } else {
                    HStack(spacing: 4) {
                        Text("距重置")
                        Text(reset, style: .relative).monospacedDigit()
                    }.font(.caption).foregroundStyle(.secondary)
                }
                Text("重置时间 \(reset.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption2).foregroundStyle(.secondary)
            } else { Text("重置时间：未知").font(.caption).foregroundStyle(.secondary) }
        }
    }
}

struct LoginView: View {
    @ObservedObject var model: MonitorModel
    let replacing: StoredAccount?
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var alias = ""
    @State private var copied = false
    var body: some View {
        NavigationStack {
            Form {
                Section("账号名称") {
                    TextField("例如：主账号", text: $alias).disabled(model.connecting)
                }
                Section {
                    Label("仅在官方页面输入密码和验证码", systemImage: "lock.shield")
                    Text("此版本实验性使用 Codex 设备码授权流程。需要在 ChatGPT 的安全设置中允许设备码登录；服务端可能拒绝第三方客户端。不要输入别人发给你的设备码。")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("添加多个账号时，先在官方页面确认当前登录的是正确账号。必要时在 Safari 切换账号后再授权。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if let challenge = model.challenge {
                    Section("本次设备码 · 15 分钟有效") {
                        Text(challenge.userCode).font(.title.monospaced().bold()).textSelection(.enabled)
                        Button(copied ? "设备码已复制" : "复制本次设备码") {
                            UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: challenge.userCode]],
                                options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(120)])
                            copied = true
                        }
                        Button("打开官方授权页") { openURL(challenge.verificationURL) }
                        Text("只向 auth.openai.com 输入本次设备码。授权完成后返回本 App；回到前台才会继续处理。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section {
                    if !model.loginStatus.isEmpty { Text(model.loginStatus).font(.subheadline) }
                    if model.connecting {
                        HStack { ProgressView(); Text("等待授权或查询结果…") }
                        Button("取消等待", role: .cancel) { model.cancelLogin() }
                    } else {
                        Button("开始官方设备授权") {
                            copied = false
                            model.connect(alias: String(alias.prefix(80)), replacing: replacing?.id)
                        }.disabled(model.busy || model.vaultUnavailable)
                    }
                }
                Section {
                    Text("不收集密码、Cookie、2FA 密钥；不提供整行密码导入。授权得到的访问与续期凭据仅存本机钥匙串，不上传开发者服务器。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle(replacing == nil ? "连接账号" : "重新授权")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { model.cancelLogin(); dismiss() } } }
            .onAppear { alias = replacing?.alias ?? "" }
        }
    }
}

struct HelpView: View {
    @ObservedObject var model: MonitorModel
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("显示的是什么") {
                    Text("Codex 的额度窗口、剩余百分比、重置时间以及接口返回的套餐类型。数据为空则显示未知，失败时保留并标明缓存值。")
                    Text("Plus 套餐类型不等于自动续费状态。不会检测信用卡扣款、订阅到期日，也不显示 GPT 聊天剩余次数。")
                }
                Section("刷新与提醒") {
                    Text("手动下拉刷新，或前台每 2 分钟刷新一次。iOS 不允许本工具在后台持续运行，倒计时到零也不代表已确认恢复额度。")
                    Button("启用预计重置提醒") { Task { await model.enableReminders() } }
                    Text("通知最多安排每账号两个窗口；锁屏通知不包含账号名称或邮箱。")
                }
                Section("隐私") {
                    Text("账号和凭据只存当前设备钥匙串，不做 iCloud 同步，不导出令牌，无统计或广告 SDK。删除账号仅移除本机记录；如需撤销授权，请使用官方账号安全设置。")
                }
                Section("实验性兼容性") {
                    Text("设备授权和额度接口参照 Codex 开源客户端实现，接口可能变化或拒绝第三方访问；本版本尚需完成真实设备授权验证。无法连接时显示错误，不模拟额度。")
                    Link("官方设备码登录说明", destination: URL(string: "https://learn.chatgpt.com/docs/auth")!)
                }
                Section("免费安装限制") {
                    Text("免费 Apple 账号签名通常 7 天过期。到期前用 Windows 上的 AltServer 刷新签名；不需要电脑全天开机。卸载、换签名或更换设备可能需要重新授权。")
                }
            }.navigationTitle("使用说明")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
        }
    }
}

private extension View {
    func card() -> some View {
        self.background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }
}
