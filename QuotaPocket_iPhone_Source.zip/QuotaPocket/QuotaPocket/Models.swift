import Foundation

struct UsageWindow: Codable, Equatable {
    let usedPercent: Double?
    let limitWindowSeconds: Double?
    let resetAfterSeconds: Double?
    let resetAt: Double?

    enum CodingKeys: String, CodingKey {
        case usedPercent = "used_percent", limitWindowSeconds = "limit_window_seconds"
        case resetAfterSeconds = "reset_after_seconds", resetAt = "reset_at"
    }
    var remaining: Double? {
        guard let usedPercent, usedPercent.isFinite, (0...100).contains(usedPercent) else { return nil }
        return 100 - usedPercent
    }
    func resetDate(observedAt: Date) -> Date? {
        if let resetAt, resetAt.isFinite, resetAt > 0 { return Date(timeIntervalSince1970: resetAt) }
        if let resetAfterSeconds, resetAfterSeconds.isFinite, resetAfterSeconds >= 0 {
            return observedAt.addingTimeInterval(resetAfterSeconds)
        }
        return nil
    }
    var title: String {
        guard let seconds = limitWindowSeconds, seconds.isFinite, seconds > 0, seconds <= 315_360_000 else { return "额度窗口" }
        if seconds == 18_000 { return "5 小时额度" }
        if seconds == 604_800 { return "每周额度" }
        if seconds.truncatingRemainder(dividingBy: 86_400) == 0 { return "\(Int(seconds / 86_400)) 天额度" }
        if seconds.truncatingRemainder(dividingBy: 3600) == 0 { return "\(Int(seconds / 3600)) 小时额度" }
        return "\(Int(seconds / 60)) 分钟额度"
    }
}

struct LimitGroup: Codable, Equatable {
    let allowed: Bool?
    let primaryWindow: UsageWindow?
    let secondaryWindow: UsageWindow?
    enum CodingKeys: String, CodingKey {
        case allowed, primaryWindow = "primary_window", secondaryWindow = "secondary_window"
    }
    var windows: [UsageWindow] { [primaryWindow, secondaryWindow].compactMap { $0 } }
}

struct AdditionalLimit: Codable, Equatable {
    let limitName: String?
    let meteredFeature: String?
    let rateLimit: LimitGroup?
    enum CodingKeys: String, CodingKey {
        case limitName = "limit_name", meteredFeature = "metered_feature", rateLimit = "rate_limit"
    }
}

struct UsagePayload: Codable, Equatable {
    let planType: String?
    let rateLimit: LimitGroup?
    let additionalRateLimits: [AdditionalLimit]?
    let accountID: String?
    enum CodingKeys: String, CodingKey {
        case planType = "plan_type", rateLimit = "rate_limit"
        case additionalRateLimits = "additional_rate_limits", accountID = "account_id"
    }
    var planLabel: String {
        guard let planType, !planType.isEmpty else { return "未知" }
        switch planType.lowercased() {
        case "plus": return "Plus"
        case "pro": return "Pro"
        case "free": return "Free"
        case "go": return "Go"
        case "team", "business": return "Business"
        default: return planType
        }
    }
    var plusStatus: String {
        guard let planType, !planType.isEmpty else { return "Plus 状态未知" }
        return planType.lowercased() == "plus" ? "本次返回套餐：Plus" : "本次返回套餐：\(planLabel)"
    }
}

struct UsageSnapshot: Codable, Equatable {
    let payload: UsagePayload
    let observedAt: Date
    func isStale(at now: Date) -> Bool { now.timeIntervalSince(observedAt) >= 300 }
}

struct StoredAccount: Identifiable, Codable, Equatable {
    var id: UUID
    var alias: String
    var email: String?
    var remoteID: String
    var snapshot: UsageSnapshot?
    var lastError: String?
}

struct Credentials: Codable {
    var accessToken: String
    var refreshToken: String?
    var idToken: String?
    var expiresAt: Date
}

struct TokenResponse: Decodable {
    let accessToken: String
    let refreshToken: String?
    let idToken: String?
    let expiresIn: Double?
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token", refreshToken = "refresh_token"
        case idToken = "id_token", expiresIn = "expires_in"
    }
    func credentials(previous: Credentials? = nil, now: Date = Date()) -> Credentials {
        let jwtExpiry = TokenClaims.payload(accessToken)?["exp"] as? Double
        let expiry = expiresIn.map { now.addingTimeInterval($0) }
            ?? jwtExpiry.map { Date(timeIntervalSince1970: $0) }
            ?? now.addingTimeInterval(300)
        return Credentials(accessToken: accessToken, refreshToken: refreshToken ?? previous?.refreshToken,
                           idToken: idToken ?? previous?.idToken, expiresAt: expiry)
    }
}

enum TokenClaims {
    // Unverified JWT fields are display/routing hints only. The server validates credentials.
    static func payload(_ token: String) -> [String: Any]? {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 3 else { return nil }
        var text = String(parts[1]).replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        text += String(repeating: "=", count: (4 - text.count % 4) % 4)
        guard let data = Data(base64Encoded: text) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }
    static func identity(_ credentials: Credentials) throws -> (accountID: String, email: String?) {
        let access = payload(credentials.accessToken) ?? [:]
        let id = credentials.idToken.flatMap { payload($0) } ?? [:]
        let auth = access["https://api.openai.com/auth"] as? [String: Any]
            ?? id["https://api.openai.com/auth"] as? [String: Any] ?? [:]
        guard let accountID = auth["chatgpt_account_id"] as? String, !accountID.isEmpty else {
            throw MonitorError.message("授权响应没有账号标识，无法安全绑定账号。")
        }
        let profile = access["https://api.openai.com/profile"] as? [String: Any]
        return (accountID, id["email"] as? String ?? profile?["email"] as? String)
    }
}

enum MonitorError: LocalizedError {
    case message(String)
    case http(Int)
    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        case .http(401): return "授权已失效，请重新连接账号。"
        case .http(403): return "服务端拒绝访问；可能需要完成官方验证或该客户端尚未获准。"
        case .http(429): return "查询过于频繁，请稍后再试。"
        case .http(let status): return "服务暂时无法完成请求（HTTP \(status)）。"
        }
    }
}

struct DeviceChallenge {
    let deviceAuthID: String
    let userCode: String
    let interval: Double
    let createdAt: Date
    let verificationURL = URL(string: "https://auth.openai.com/codex/device")!
}
