import Foundation
import Combine

@MainActor final class MonitorModel: ObservableObject {
    @Published private(set) var accounts: [StoredAccount] = []
    @Published private(set) var busy = false
    @Published var message: String?
    @Published private(set) var challenge: DeviceChallenge?
    @Published private(set) var loginStatus = ""
    @Published private(set) var connecting = false
    @Published private(set) var vaultUnavailable = false

    private var vault = Vault()
    private let api: ProviderAPI
    private var loginTask: Task<Void, Never>?
    private var activeLoginID: UUID?
    private var refreshing: Set<UUID> = []
    init(api: ProviderAPI = ProviderAPI()) {
        self.api = api
        do { vault = try VaultStore.read(); accounts = vault.accounts }
        catch { vaultUnavailable = true; message = "本机账号库读取失败；为防止覆盖已有数据，已暂停写入。请重新启动后重试。" }
    }
    private func commit(_ next: Vault) throws {
        guard !vaultUnavailable else { throw MonitorError.message("账号库尚未成功读取，不能写入。") }
        try VaultStore.write(next)
        vault = next
        accounts = next.accounts
    }
    func connect(alias: String, replacing: UUID? = nil) {
        guard !busy, !connecting, refreshing.isEmpty, !vaultUnavailable else { return }
        let loginID = UUID()
        activeLoginID = loginID
        challenge = nil
        connecting = true
        loginStatus = "正在请求设备授权…"
        loginTask = Task {
            defer {
                if activeLoginID == loginID {
                    connecting = false
                    challenge = nil
                    activeLoginID = nil
                }
            }
            do {
                let code = try await api.beginLogin()
                try Task.checkCancellation()
                challenge = code
                loginStatus = "请打开官方页面，输入本次设备码；授权后返回这里。"
                let credentials = try await api.finishLogin(code)
                try Task.checkCancellation()
                let identity = try TokenClaims.identity(credentials)
                var next = vault
                let id = replacing ?? UUID()
                if let replacing, let old = next.accounts.first(where: { $0.id == replacing }) {
                    guard old.remoteID == identity.accountID,
                          old.email == nil || identity.email == nil || old.email == identity.email else {
                        throw MonitorError.message("登录的账号与原账号不一致，已取消覆盖。请用添加账号连接。")
                    }
                }
                let old = next.accounts.first(where: { $0.id == id })
                let account = StoredAccount(id: id, alias: alias.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "我的账号" : alias,
                    email: identity.email, remoteID: identity.accountID, snapshot: nil, lastError: nil)
                if let index = next.accounts.firstIndex(where: { $0.id == id }) { next.accounts[index] = account }
                else {
                    guard next.accounts.count < 20 else { throw MonitorError.message("当前版本最多连接 20 个账号。") }
                    next.accounts.append(account)
                }
                next.credentials[id.uuidString] = credentials
                try commit(next)
                if old != nil { Reminders.clear(account: id) }
                loginStatus = "授权成功，正在查询…"
                await refreshOne(id)
                loginStatus = "已连接，可返回账号列表。"
            } catch is CancellationError {
                if activeLoginID == loginID { loginStatus = "已取消本机等待。" }
            } catch {
                if activeLoginID == loginID { loginStatus = readable(error) }
            }
        }
    }
    func cancelLogin() {
        loginTask?.cancel()
        activeLoginID = nil
        connecting = false
        challenge = nil
    }
    func refreshAll() async {
        guard !busy, !connecting, !vaultUnavailable else { return }
        busy = true
        defer { busy = false }
        let ids = accounts.map(\.id)
        for id in ids {
            if Task.isCancelled { break }
            await refreshOne(id)
        }
    }
    private func refreshOne(_ id: UUID) async {
        guard !refreshing.contains(id) else { return }
        refreshing.insert(id)
        defer { refreshing.remove(id) }
        guard let account = vault.accounts.first(where: { $0.id == id }) else { return }
        do {
            guard var credentials = vault.credentials[id.uuidString] else {
                throw MonitorError.message("本机凭据缺失，请重新连接。")
            }
            if credentials.expiresAt.timeIntervalSinceNow < 60 {
                credentials = try await renew(credentials, id: id, expectedID: account.remoteID)
            }
            guard try TokenClaims.identity(credentials).accountID == account.remoteID else {
                throw MonitorError.message("本机凭据与账号绑定不一致，请重新连接。")
            }
            let payload: UsagePayload
            do { payload = try await api.usage(credentials: credentials, accountID: account.remoteID) }
            catch MonitorError.http(401) {
                credentials = try await renew(credentials, id: id, expectedID: account.remoteID)
                payload = try await api.usage(credentials: credentials, accountID: account.remoteID)
            }
            var next = vault
            guard let index = next.accounts.firstIndex(where: { $0.id == id }) else { return }
            next.accounts[index].snapshot = UsageSnapshot(payload: payload, observedAt: Date())
            next.accounts[index].lastError = nil
            try commit(next)
            await Reminders.schedule(account: next.accounts[index])
        } catch {
            var next = vault
            if let index = next.accounts.firstIndex(where: { $0.id == id }) {
                next.accounts[index].lastError = readable(error)
                do { try commit(next) } catch { message = "账号状态保存失败。请检查设备钥匙串是否可用。" }
            }
        }
    }
    private func renew(_ old: Credentials, id: UUID, expectedID: String) async throws -> Credentials {
        let renewed = try await api.refresh(old)
        // Save rotated credentials before any follow-up request, even if the usage request later fails.
        var next = vault
        guard next.accounts.contains(where: { $0.id == id }) else { throw CancellationError() }
        next.credentials[id.uuidString] = renewed
        try commit(next)
        guard try TokenClaims.identity(renewed).accountID == expectedID else {
            throw MonitorError.message("续期响应账号不一致，请重新连接。")
        }
        return renewed
    }
    func rename(_ id: UUID, alias: String) {
        guard !busy, !connecting, refreshing.isEmpty else { return }
        var next = vault
        if let index = next.accounts.firstIndex(where: { $0.id == id }) {
            next.accounts[index].alias = alias.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "我的账号" : alias
            do { try commit(next) } catch { message = readable(error) }
        }
    }
    func remove(_ id: UUID) {
        guard !busy, !connecting, refreshing.isEmpty else { return }
        var next = vault
        next.accounts.removeAll { $0.id == id }
        next.credentials.removeValue(forKey: id.uuidString)
        do { try commit(next); Reminders.clear(account: id) }
        catch { message = readable(error) }
    }
    func enableReminders() async {
        do {
            if try await Reminders.enable() {
                for account in accounts { await Reminders.schedule(account: account) }
                message = "已启用预计重置时间提醒。额度是否恢复，需要刷新核对。"
            } else { message = "通知未获允许；可以在 iPhone 设置中开启。" }
        } catch { message = "无法设置通知，请检查 iPhone 通知设置。" }
    }
    private func readable(_ error: Error) -> String {
        if let error = error as? MonitorError { return error.localizedDescription }
        if error is DecodingError { return "服务响应格式已变化，无法可靠读取额度。" }
        if let error = error as? URLError {
            if error.code == .cancelled { return "请求已取消。" }
            return "网络请求失败，请检查连接后重试（\(error.code.rawValue)）。"
        }
        return "操作未完成，请重新连接或重试。"
    }
}
