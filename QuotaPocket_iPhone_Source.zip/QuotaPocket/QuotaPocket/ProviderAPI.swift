import Foundation

// Experimental compatibility adapter for the public Codex client flow.
// These are provider-owned endpoints, not a guaranteed public third-party API.
enum ProviderConfig {
    static let authOrigin = "https://auth.openai.com"
    static let usageURL = URL(string: "https://chatgpt.com/backend-api/wham/usage")!
    static let clientID = "app_EMoamEEZ73f0CkXaXp7hrann"
}

final class NoRedirectDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class ProviderAPI {
    private let session: URLSession
    init(session: URLSession? = nil) {
        if let session { self.session = session; return }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 45
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        config.urlCredentialStorage = nil
        config.urlCache = nil
        self.session = URLSession(configuration: config, delegate: NoRedirectDelegate(), delegateQueue: nil)
    }

    private func send(_ request: URLRequest) async throws -> (Data, Int) {
        guard let url = request.url, url.scheme == "https",
              ["auth.openai.com", "chatgpt.com"].contains(url.host ?? "") else {
            throw MonitorError.message("已拒绝向非官方地址发送授权数据。")
        }
        let (data, response) = try await session.data(for: request)
        guard let response = response as? HTTPURLResponse else { throw MonitorError.message("响应无效。") }
        return (data, response.statusCode)
    }

    private func jsonPost(path: String, body: [String: String]) throws -> URLRequest {
        var request = URLRequest(url: URL(string: ProviderConfig.authOrigin + path)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        return request
    }

    func beginLogin() async throws -> DeviceChallenge {
        let request = try jsonPost(path: "/api/accounts/deviceauth/usercode", body: ["client_id": ProviderConfig.clientID])
        let (data, status) = try await send(request)
        guard (200...299).contains(status) else { throw MonitorError.http(status) }
        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let device = object["device_auth_id"] as? String, !device.isEmpty,
              let code = (object["user_code"] ?? object["usercode"]) as? String, !code.isEmpty else {
            throw MonitorError.message("设备授权响应格式已变化。")
        }
        let interval = (object["interval"] as? NSNumber)?.doubleValue
            ?? (object["interval"] as? String).flatMap(Double.init) ?? 5
        return DeviceChallenge(deviceAuthID: device, userCode: code,
                               interval: min(60, max(5, interval)), createdAt: Date())
    }

    func finishLogin(_ challenge: DeviceChallenge) async throws -> Credentials {
        let deadline = challenge.createdAt.addingTimeInterval(15 * 60)
        while Date() < deadline {
            try Task.checkCancellation()
            let request = try jsonPost(path: "/api/accounts/deviceauth/token", body: [
                "device_auth_id": challenge.deviceAuthID, "user_code": challenge.userCode
            ])
            let (data, status) = try await send(request)
            if status == 403 || status == 404 {
                try await Task.sleep(nanoseconds: UInt64(challenge.interval * 1_000_000_000))
                continue
            }
            guard (200...299).contains(status) else { throw MonitorError.http(status) }
            struct Approved: Decodable { let authorization_code: String; let code_verifier: String }
            let approved = try JSONDecoder().decode(Approved.self, from: data)
            return try await tokenRequest([
                "grant_type": "authorization_code", "client_id": ProviderConfig.clientID,
                "code": approved.authorization_code, "code_verifier": approved.code_verifier,
                "redirect_uri": ProviderConfig.authOrigin + "/deviceauth/callback"
            ]).credentials()
        }
        throw MonitorError.message("设备授权已超过 15 分钟，请重新开始。")
    }

    func refresh(_ credentials: Credentials) async throws -> Credentials {
        guard let refresh = credentials.refreshToken, !refresh.isEmpty else {
            throw MonitorError.message("没有可用的续期凭据，请重新连接账号。")
        }
        let response = try await tokenRequest([
            "grant_type": "refresh_token", "client_id": ProviderConfig.clientID, "refresh_token": refresh
        ])
        return response.credentials(previous: credentials)
    }

    private func tokenRequest(_ fields: [String: String]) async throws -> TokenResponse {
        var request = URLRequest(url: URL(string: ProviderConfig.authOrigin + "/oauth/token")!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
        request.httpBody = fields.sorted { $0.key < $1.key }.map { key, value in
            "\(key.addingPercentEncoding(withAllowedCharacters: allowed)!)=\(value.addingPercentEncoding(withAllowedCharacters: allowed)!)"
        }.joined(separator: "&").data(using: .utf8)
        let (data, status) = try await send(request)
        guard (200...299).contains(status) else { throw MonitorError.http(status) }
        return try JSONDecoder().decode(TokenResponse.self, from: data)
    }

    func usage(credentials: Credentials, accountID: String) async throws -> UsagePayload {
        var request = URLRequest(url: ProviderConfig.usageURL)
        request.setValue("Bearer " + credentials.accessToken, forHTTPHeaderField: "Authorization")
        request.setValue(accountID, forHTTPHeaderField: "ChatGPT-Account-Id")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, status) = try await send(request)
        guard (200...299).contains(status) else { throw MonitorError.http(status) }
        let payload = try JSONDecoder().decode(UsagePayload.self, from: data)
        if let returnedID = payload.accountID, returnedID != accountID {
            throw MonitorError.message("响应账号与所选账号不一致，已拒绝保存。")
        }
        guard payload.planType != nil || payload.rateLimit != nil || payload.additionalRateLimits != nil else {
            throw MonitorError.message("响应不含额度或套餐字段，不能判定为查询成功。")
        }
        return payload
    }
}
