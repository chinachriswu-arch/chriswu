import SwiftUI

@main struct QuotaPocketApp: App {
    @StateObject private var model = MonitorModel()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .tint(Color(red: 0.18, green: 0.43, blue: 0.32))
                .overlay {
                    if scenePhase != .active {
                        Color(uiColor: .systemBackground).ignoresSafeArea()
                            .overlay { Label("额度口袋", systemImage: "lock.shield").font(.title2) }
                    }
                }
                .task(id: scenePhase) {
                    guard scenePhase == .active else { return }
                    await model.refreshAll()
                    while !Task.isCancelled {
                        do { try await Task.sleep(nanoseconds: 120_000_000_000) }
                        catch { return }
                        guard !Task.isCancelled else { return }
                        await model.refreshAll()
                    }
                }
        }
    }
}
