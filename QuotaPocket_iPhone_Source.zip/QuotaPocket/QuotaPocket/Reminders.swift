import Foundation
import UserNotifications

enum Reminders {
    static func enable() async throws -> Bool {
        try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
    }
    static func clear(account: UUID) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: (0..<32).map { "reset.\(account.uuidString).\($0)" }
        )
    }
    static func schedule(account: StoredAccount) async {
        clear(account: account.id)
        guard let snapshot = account.snapshot else { return }
        let center = UNUserNotificationCenter.current()
        let permission = await center.notificationSettings()
        guard permission.authorizationStatus == .authorized || permission.authorizationStatus == .provisional else { return }
        let groups = [snapshot.payload.rateLimit].compactMap { $0 }
            + (snapshot.payload.additionalRateLimits ?? []).compactMap { $0.rateLimit }
        let dates = groups.flatMap { $0.windows }.compactMap { $0.resetDate(observedAt: snapshot.observedAt) }
        // Keep well below iOS's pending-notification limit for multi-account use.
        for (i, date) in dates.filter({ $0.timeIntervalSinceNow > 1 }).prefix(2).enumerated() {
            let content = UNMutableNotificationContent()
            content.title = "Codex 额度时间提醒"
            content.body = "一个已记录的额度窗口到达预计重置时间。打开额度口袋核对最新值。"
            content.sound = .default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, date.timeIntervalSinceNow), repeats: false)
            let request = UNNotificationRequest(identifier: "reset.\(account.id.uuidString).\(i)", content: content, trigger: trigger)
            try? await center.add(request)
        }
    }
}
