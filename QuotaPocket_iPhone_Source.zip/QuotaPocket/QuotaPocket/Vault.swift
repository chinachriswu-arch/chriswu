import Foundation
import Security

struct Vault: Codable {
    var accounts: [StoredAccount] = []
    var credentials: [String: Credentials] = [:]
}

enum VaultStore {
    private static let service = "local.quotapocket.vault.v1"
    private static var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service, kSecAttrAccount as String: "accounts"]
    }
    static func read() throws -> Vault {
        var request = query
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &result)
        if status == errSecItemNotFound { return Vault() }
        guard status == errSecSuccess, let data = result as? Data else {
            throw MonitorError.message("无法读取本机钥匙串（\(status)）。请解锁设备后重试。")
        }
        return try JSONDecoder().decode(Vault.self, from: data)
    }
    static func write(_ vault: Vault) throws {
        let data = try JSONEncoder().encode(vault)
        let update: [String: Any] = [kSecValueData as String: data]
        let status = SecItemUpdate(query as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var item = query
            item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            let addStatus = SecItemAdd(item as CFDictionary, nil)
            guard addStatus == errSecSuccess else { throw MonitorError.message("无法保存到本机钥匙串（\(addStatus)）。") }
        } else if status != errSecSuccess {
            throw MonitorError.message("无法更新本机钥匙串（\(status)）。")
        }
    }
}
