import XCTest
@testable import QuotaPocket

final class MockProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, body) = try Self.handler!(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil,
                                           headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: body)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class ProviderTests: XCTestCase {
    override func tearDown() { MockProtocol.handler = nil; super.tearDown() }
    private func api() -> ProviderAPI {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockProtocol.self]
        return ProviderAPI(session: URLSession(configuration: config))
    }
    private var credentials: Credentials {
        Credentials(accessToken: "TEST-ONLY-NOT-A-REAL-TOKEN", refreshToken: nil, idToken: nil, expiresAt: .distantFuture)
    }
    func testUsageBindsAccountAndSendsAuthorizationOnlyToOfficialEndpoint() async throws {
        MockProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://chatgpt.com/backend-api/wham/usage")
            XCTAssertEqual(request.value(forHTTPHeaderField: "ChatGPT-Account-Id"), "test-account")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer TEST-ONLY-NOT-A-REAL-TOKEN")
            return (200, Data(#"{"account_id":"test-account","plan_type":"plus"}"#.utf8))
        }
        let usage = try await api().usage(credentials: credentials, accountID: "test-account")
        XCTAssertEqual(usage.planLabel, "Plus")
    }
    func testDifferentAccountAndEmptyPayloadAreRejected() async {
        for response in [#"{"account_id":"wrong","plan_type":"plus"}"#, "{}"] {
            MockProtocol.handler = { _ in (200, Data(response.utf8)) }
            do {
                _ = try await api().usage(credentials: credentials, accountID: "test-account")
                XCTFail("Must reject mismatched or empty response")
            } catch { XCTAssertTrue(error is MonitorError) }
        }
    }
    func testAuthFailureNeverLooksLikeZeroQuota() async {
        MockProtocol.handler = { _ in (401, Data(#"{"detail":"unauthorized"}"#.utf8)) }
        do {
            _ = try await api().usage(credentials: credentials, accountID: "test-account")
            XCTFail("Must reject HTTP 401")
        } catch { XCTAssertTrue(error is MonitorError) }
    }
    func testDeviceCodeSupportsStringIntervalAndLegacyUsercode() async throws {
        MockProtocol.handler = { request in
            XCTAssertEqual(request.url?.host, "auth.openai.com")
            XCTAssertEqual(request.url?.path, "/api/accounts/deviceauth/usercode")
            return (200, Data(#"{"device_auth_id":"test-device","usercode":"TEST-CODE","interval":"5"}"#.utf8))
        }
        let challenge = try await api().beginLogin()
        XCTAssertEqual(challenge.userCode, "TEST-CODE")
        XCTAssertEqual(challenge.interval, 5)
    }
    func testCodeExchangeUsesExpectedRedirectAndDoesNotSendPasswords() async throws {
        MockProtocol.handler = { request in
            if request.url?.path == "/api/accounts/deviceauth/token" {
                return (200, Data(#"{"authorization_code":"test-code","code_verifier":"test-verifier"}"#.utf8))
            }
            XCTAssertEqual(request.url?.path, "/oauth/token")
            // Read httpBodyStream because URLSession may move httpBody into a stream.
            var data = request.httpBody ?? Data()
            if data.isEmpty, let stream = request.httpBodyStream {
                stream.open(); defer { stream.close() }
                var buffer = [UInt8](repeating: 0, count: 1024)
                while stream.hasBytesAvailable {
                    let count = stream.read(&buffer, maxLength: buffer.count)
                    if count <= 0 { break }
                    data.append(contentsOf: buffer.prefix(count))
                }
            }
            let body = String(data: data, encoding: .utf8) ?? ""
            XCTAssertTrue(body.contains("grant_type=authorization_code"))
            XCTAssertTrue(body.contains("code_verifier=test-verifier"))
            XCTAssertTrue(body.contains("deviceauth%2Fcallback"))
            XCTAssertFalse(body.contains("password"))
            return (200, Data(#"{"access_token":"TEST-ONLY","refresh_token":"TEST-REFRESH","expires_in":3600}"#.utf8))
        }
        let challenge = DeviceChallenge(deviceAuthID: "test-device", userCode: "TEST-CODE", interval: 5, createdAt: .now)
        let result = try await api().finishLogin(challenge)
        XCTAssertEqual(result.accessToken, "TEST-ONLY")
    }
}
