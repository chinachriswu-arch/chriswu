import XCTest
@testable import QuotaPocket

final class UsageTests: XCTestCase {
    func testRealisticUsageAndAdditionalPools() throws {
        let data = Data(#"{"plan_type":"plus","rate_limit":{"allowed":true,"primary_window":{"used_percent":35,"limit_window_seconds":18000,"reset_after_seconds":60,"reset_at":2000000000},"secondary_window":{"used_percent":90,"limit_window_seconds":604800,"reset_at":2000100000}},"additional_rate_limits":[{"limit_name":"Spark","metered_feature":"spark","rate_limit":{"primary_window":{"used_percent":20,"limit_window_seconds":18000}}}],"unknown_future_field":true}"#.utf8)
        let payload = try JSONDecoder().decode(UsagePayload.self, from: data)
        XCTAssertEqual(payload.planLabel, "Plus")
        XCTAssertEqual(payload.rateLimit?.primaryWindow?.remaining, 65)
        XCTAssertEqual(payload.rateLimit?.secondaryWindow?.remaining, 10)
        XCTAssertEqual(payload.rateLimit?.primaryWindow?.title, "5 小时额度")
        XCTAssertEqual(payload.rateLimit?.secondaryWindow?.title, "每周额度")
        XCTAssertEqual(payload.additionalRateLimits?.first?.rateLimit?.primaryWindow?.remaining, 80)
    }
    func testMissingValuesAreNotFullQuotaOrFree() throws {
        let payload = try JSONDecoder().decode(UsagePayload.self, from: Data(#"{"plan_type":null,"rate_limit":{"primary_window":{}}}"#.utf8))
        XCTAssertEqual(payload.planLabel, "未知")
        XCTAssertEqual(payload.plusStatus, "Plus 状态未知")
        XCTAssertNil(payload.rateLimit?.primaryWindow?.remaining)
        XCTAssertNil(payload.rateLimit?.primaryWindow?.resetDate(observedAt: .now))
    }
    func testMalformedQuotaIsUnknown() {
        for percent in [-1.0, 101.0, .infinity, .nan] {
            let window = UsageWindow(usedPercent: percent, limitWindowSeconds: nil, resetAfterSeconds: nil, resetAt: nil)
            XCTAssertNil(window.remaining)
        }
    }
    func testResetAfterUsesSnapshotTimeNotCurrentTime() {
        let observed = Date(timeIntervalSince1970: 1000)
        let window = UsageWindow(usedPercent: 100, limitWindowSeconds: 18_000, resetAfterSeconds: 60, resetAt: nil)
        XCTAssertEqual(window.resetDate(observedAt: observed), Date(timeIntervalSince1970: 1060))
        // A passed reset never mutates usedPercent to 0 or remaining to 100.
        XCTAssertEqual(window.remaining, 0)
    }
    func testAbsoluteResetHasPriorityAndCacheExpires() {
        let window = UsageWindow(usedPercent: 40, limitWindowSeconds: 18_000, resetAfterSeconds: 60, resetAt: 2000)
        let observed = Date(timeIntervalSince1970: 1000)
        XCTAssertEqual(window.resetDate(observedAt: observed), Date(timeIntervalSince1970: 2000))
        let snapshot = UsageSnapshot(payload: UsagePayload(planType: "pro", rateLimit: nil, additionalRateLimits: nil, accountID: nil), observedAt: observed)
        XCTAssertFalse(snapshot.isStale(at: observed.addingTimeInterval(299)))
        XCTAssertTrue(snapshot.isStale(at: observed.addingTimeInterval(300)))
    }
    func testRotatingRefreshPreservesIDTokenAndOldRefreshIfOmitted() throws {
        let old = Credentials(accessToken: "old", refreshToken: "refresh-old", idToken: "id-old", expiresAt: .distantPast)
        let response = try JSONDecoder().decode(TokenResponse.self, from: Data(#"{"access_token":"new","expires_in":3600}"#.utf8))
        let now = Date(timeIntervalSince1970: 1000)
        let new = response.credentials(previous: old, now: now)
        XCTAssertEqual(new.refreshToken, "refresh-old")
        XCTAssertEqual(new.idToken, "id-old")
        XCTAssertEqual(new.expiresAt, now.addingTimeInterval(3600))
        let rotated = try JSONDecoder().decode(TokenResponse.self, from: Data(#"{"access_token":"new","refresh_token":"refresh-new"}"#.utf8))
        XCTAssertEqual(rotated.credentials(previous: old).refreshToken, "refresh-new")
    }
    func testIdentityRequiresAccountAndDoesNotTrustArbitraryPlaintext() throws {
        XCTAssertNil(TokenClaims.payload("not-a-jwt"))
        let credentials = Credentials(accessToken: "invalid", refreshToken: nil, idToken: nil, expiresAt: .now)
        XCTAssertThrowsError(try TokenClaims.identity(credentials))
    }
}
