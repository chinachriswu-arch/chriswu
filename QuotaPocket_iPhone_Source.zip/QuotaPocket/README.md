# 额度口袋 · QuotaPocket

一个面向 iPhone 的个人 Codex 额度监控项目。不是 AI Limits Tracker 的修改版，也不是 OpenAI 官方应用。

**交付状态：源码和 GitHub 编译工作流已提供；尚未完成 Xcode 编译、真机安装或真实账号授权验证。没有在此交付中生成可安装 IPA。**

## 当前实现

- 多个 ChatGPT / Codex 授权账号（本版上限 20 个），账号名称和搜索。
- 基于设备码的官方页面授权，不输入或保存密码、2FA 密钥。
- 使用访问凭据查询 Codex 额度窗口及附加额度池，显示剩余百分比。
- 重置绝对时间、相对倒计时、前台自动刷新和手动下拉刷新。
- 显示额度响应中的套餐类型（例如 Plus、Pro、Free）。
- 提供预计重置时间的本地通知，需要用户在 App 中启用。
- 账号及访问/续期凭据存于当前设备钥匙串，不存明文文件，不放进 GitHub。
- 原生 SwiftUI 界面，支持 iOS 17 及以上，无第三方运行时依赖。

## 必须知道的边界

1. **Codex 额度不是 ChatGPT 对话次数。** 此工具不会计算 GPT 聊天剩余次数。
2. `plan_type=plus` 仅说明本次额度响应返回了 Plus 套餐，不能推导账单、自动续费、订阅到期日或付款是否成功。到期日显示未知。
3. 额度和授权兼容层参考公开 Codex 源码中的客户端协议，是实验性实现。并非承诺对第三方长期开放的 API，服务端可能拒绝；拒绝时不会绕过验证或模拟成功。正式分发前应确认适用的开发者授权、注册流程和服务条款。
4. 这不是常驻后台服务。只有前台会每 2 分钟查询。后台倒计时/本地提醒依据上次成功的快照，不证明额度已经恢复。
5. 已过重置时间不会自动将额度改为 100%；超过 5 分钟或请求失败会标记缓存。
6. 本版没有桌面小组件、Apple Watch、iCloud 同步、自动切换 ChatGPT 登录，也不承诺 AI Limits Tracker 的全部功能。
7. 免费 Apple 账号安装通常 7 天到期，必须定期重新签名。若需要一直不续签、无需电脑且不付费，这条安装路线不能满足。

## Windows 用户从这里开始

见 **[Windows安装指南.md](Windows安装指南.md)**。整个流程是：

1. 自己创建 GitHub 公开仓库，将本项目源码上传到仓库根目录。
2. GitHub Actions 的 macOS 运行器生成 Xcode 工程、运行单元测试、编译未签名 IPA。
3. 下载构建产物，用 Windows 的 AltStore Classic / AltServer 本地签名安装。
4. 在 iPhone 上自行进行官方账号授权，验证真实数据读取。

**电脑只在首次安装和每周续签时需要开机，不作为额度查询服务器。** Apple 账号、密码、设备码和账号令牌均不要交给他人，也不要放进 GitHub Actions Secrets；这个构建流程完全不需要这些信息。

## 项目文件

| 文件 | 用途 |
|---|---|
| `QuotaPocket/Models.swift` | 额度响应解析、缓存、时间和 JWT 字段提示 |
| `QuotaPocket/ProviderAPI.swift` | 设备授权、凭据续期、只读额度请求 |
| `QuotaPocket/Vault.swift` | 本机钥匙串存储 |
| `QuotaPocket/MonitorModel.swift` | 多账号状态和顺序刷新 |
| `QuotaPocket/ContentView.swift` | 原生手机界面 |
| `QuotaPocket/Reminders.swift` | 预计重置本地通知 |
| `QuotaPocketTests/` | XCTest 模型与模拟网络测试 |
| `project.yml` | XcodeGen 工程定义 |
| `.github/workflows/build-ios.yml` | 免费云端编译与测试配置 |

## 本地有 Mac 时（可选）

```sh
brew install xcodegen
xcodegen generate
open QuotaPocket.xcodeproj
```

项目默认关闭签名以供云端生成未签名构建。若用 Xcode 直接真机安装，需要在自己的机器上配置 Personal Team 并调整签名设置。

## 验证状态

见 [VALIDATION.md](VALIDATION.md)。仅本次实际运行的检查可视为已通过；工作流中的 XCTest 和 Xcode 编译需要上传 GitHub 后运行。源码交付不等于自动获得 Apple 或 OpenAI 访问授权。

## 依据与维护

协议来源和官方安装文档见 [REFERENCES.md](REFERENCES.md)。设备授权需先在官方账号安全设置中允许。接口拒绝、需要人机验证或新增授权要求时应停止，按官方说明处理，不伪造客户端或规避验证。
