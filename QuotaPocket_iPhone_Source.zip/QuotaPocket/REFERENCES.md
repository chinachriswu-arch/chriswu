# 实现与安装依据

核对日期：2026-10-25。本项目是独立实现，不包含 AI Limits Tracker 的商业应用源码或授权。

- OpenAI：设备码登录与账号安全设置 https://learn.chatgpt.com/docs/auth
- OpenAI：App server 账号/额度读取说明 https://learn.chatgpt.com/docs/app-server
- 协议字段核对使用 OpenAI 官方公开仓库 `openai/codex`，提交 `970111f6cb62cc02fe36a82ea7d71b37a2889c97`：
  - `codex-rs/login/src/device_code_auth.rs`：设备码请求/轮询/授权码交换。
  - `codex-rs/login/src/oauth/client.rs`：表单 token 交换/续期。
  - `codex-rs/login/src/auth/manager.rs`：现有 Codex 公开客户端标识。
  - `codex-rs/backend-client/src/client/rate_limit_resets.rs`：只读额度接口。
  - `codex-rs/codex-backend-openapi-models/src/models/rate_limit_status_payload.rs`、`rate_limit_window_snapshot.rs`：套餐与额度窗口字段。
  - https://github.com/openai/codex/tree/970111f6cb62cc02fe36a82ea7d71b37a2889c97
- GitHub 标准运行器计费说明：https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- Apple 免费账号/7 天限制：https://developer.apple.com/help/account/basics/about-your-developer-account/
- AltStore Classic Windows 安装：https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows
- AltStore 免费应用刷新限制：https://faq.altstore.io/altstore-classic/your-altstore

接口兼容声明：公开客户端协议不等于注册了新的第三方 OAuth 客户端，也不构成长期支持承诺。`ProviderConfig` 集中保存实验性端点和客户端标识。正式分发前，维护者应依据官方最新开放接入方式迁移、注册并完成真实授权验证。本包不规避服务端验证或权限限制。
