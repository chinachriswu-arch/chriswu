# Windows 安装指南

## 你需要准备

- Windows 电脑、iPhone（iOS 17 或以上）及数据线。
- 自己的免费 GitHub 账号、Apple 账号和可正常登录的 ChatGPT 账号。
- 电脑和手机能访问相应官方服务。

不需要购买 Mac，不需要购买 Apple 开发者年费。免费方式需要每 7 天左右刷新签名，不是永久免维护安装。AltServer、Apple 登录或网络可用性需要在你的设备上实际验证。

## 第一步：让 GitHub 编译

1. 解压这个压缩包，打开 `QuotaPocket` 文件夹。
2. 登录 [github.com](https://github.com)，新建一个 **Public（公开）** 仓库，例如 `quota-pocket`。
3. 使用仓库的 **Add file → Upload files**，上传本文件夹内的全部项目内容。目录关系必须保持如下：仓库首页能直接看到 `project.yml`、`QuotaPocket`、`QuotaPocketTests` 和 `.github` 文件夹，不要再多套一层文件夹。`.github` 必须包含 `workflows/build-ios.yml`。不要上传本人的密码、邮箱密码清单、Cookie 或 `auth.json`。
4. 打开仓库 **Actions**。如提示启用工作流，确认这是你刚上传的构建配置后自行启用。
5. 选择 **Build iPhone app → Run workflow**，等待完成。首次可能需要十几分钟。
6. 只有工作流显示绿色成功，才算通过 Xcode 编译和该工作流中的单元测试。失败时，发红色步骤名称和去除私人信息的错误日志以便修复；不要直接跳过测试。
7. 在这次运行页面下方 **Artifacts** 下载 `QuotaPocket-unsigned-ipa`，解压得到 `QuotaPocket-unsigned.ipa`。

这份 IPA 尚未签名，不能通过 Safari 点击直接安装。源码公开，不代表账号公开；这个项目不会把运行中的账号数据写回仓库。GitHub 的公开仓库标准运行器免费，但不要选择付费的大型运行器、不要购买付费服务。私有仓库计费规则不同。

## 第二步：用 Windows 免费安装

按 AltStore 官方的 [Windows 安装说明](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows) 安装 **AltStore Classic / AltServer**。不要把欧盟的 AltStore PAL 当成这条安装路线。

主要步骤：

1. 只从 [altstore.io](https://altstore.io/) 获取 AltServer。
2. 按官方说明安装所需 Apple 组件（说明中指定 Apple 版 iTunes/iCloud 时，遵照说明，不随意用 Microsoft Store 版替代）。
3. 用数据线连接并在 iPhone 上选择信任自己的电脑。
4. 用 AltServer 将 AltStore 安装到 iPhone。Apple 账号在你自己的电脑界面输入，不发给我，也不写进 GitHub。
5. 按系统提示完成开发者信任；需要时开启开发者模式。
6. 将未签名 IPA 放进 iPhone“文件”App。AltStore 的 **My Apps → ＋** 中选择这份 IPA，执行本地签名安装。受 Apple 免费账号限制，App 数量/App ID 可能有限；以 AltStore 提示为准。
7. 打开“额度口袋”。

**如果安装阶段报错，先解决安装，不要把 Apple 账号或 ChatGPT 凭据粘贴到聊天里。**

## 第三步：连接账号

1. 在手机上登录自己的 ChatGPT 账号，按 [官方设备码说明](https://learn.chatgpt.com/docs/auth) 在账号安全设置中允许设备码登录。工作区可能由管理员控制。
2. 打开“额度口袋”→ 添加账号 → 填写本机备注名 → 开始官方设备授权。
3. 点击复制本次设备码，再打开官方授权页。确认域名是 `auth.openai.com`，只输入你自己刚在 App 内发起的设备码。
4. 在官方页面自行登录并完成授权，随后返回 App。
5. 若读取成功，账号卡片会显示真实响应、上次成功时间、额度和套餐；若服务端拒绝，卡片显示错误，不能把它当成已连接成功的额度监控。
6. 添加第二个账号前，在官方授权页确认登录的是第二个账号；必要时先在 Safari 切换登录。

此 App 使用实验性的 Codex 设备授权兼容层。如果服务端不允许该客户端，必须先解决官方授权接入问题；免费编译和安装本身不能保证接口授权。

## 每周维护

- 免费安装的 App 通常 7 天到期。到期前通过 AltStore/AltServer 刷新签名，按官方流程让手机与电脑连接。
- 平时不用开电脑，手机直接请求服务商。
- 不要轻易卸载 App；更换 Apple 账号、签名标识或设备可能需要重新授权。
- 删除本机账号不取消 Plus 订阅，也不一定撤销服务端授权。撤销授权请去官方安全设置处理。

## 如果你只想完成第一步

先创建 GitHub 仓库并上传项目即可。下一步可以发 **仓库 Actions 页面截图**，遮住私人信息。我能据此帮你定位构建步骤，不需要你提供密码。
