"""Local structural checks, not a replacement for xcodebuild or XCTest."""
from pathlib import Path
import json
import plistlib
import yaml

root = Path(__file__).resolve().parents[1]
project = yaml.safe_load((root / "project.yml").read_text())
assert set(project["targets"]) == {"QuotaPocket", "QuotaPocketTests"}
for target in project["targets"].values():
    for source in target["sources"]:
        assert (root / source).is_dir(), source
workflow = yaml.load((root / ".github/workflows/build-ios.yml").read_text(), Loader=yaml.BaseLoader)
assert workflow["jobs"]["build"]["runs-on"] == "macos-latest"
steps = workflow["jobs"]["build"]["steps"]
assert any("test CODE_SIGNING_ALLOWED=NO" in s.get("run", "") for s in steps)
assert any("generic/platform=iOS" in s.get("run", "") for s in steps)
for path in root.rglob("*.json"):
    json.loads(path.read_text())
with (root / "QuotaPocket/PrivacyInfo.xcprivacy").open("rb") as f:
    privacy = plistlib.load(f)
assert privacy["NSPrivacyTracking"] is False
swift = list(root.rglob("*.swift"))
assert len(swift) == 9
test_count = sum(p.read_text().count("    func test") for p in (root / "QuotaPocketTests").glob("*.swift"))
assert test_count == 12, test_count
assert not list(root.rglob("auth.json"))
assert not list(root.rglob("*.p12"))
assert not list(root.rglob("*.mobileprovision"))
print(f"PASS: project structure, YAML, privacy plist, JSON; {len(swift)} Swift files; {test_count} test methods present.")
try:
    from tree_sitter import Language, Parser
    import tree_sitter_swift
except ImportError:
    print("SKIP: Swift grammar parser not installed. Use Xcode for authoritative compilation.")
else:
    parser = Parser(Language(tree_sitter_swift.language()))
    for path in swift:
        tree = parser.parse(path.read_bytes())
        assert not tree.root_node.has_error, f"Syntax error: {path}"
    print("PASS: Swift grammar parsing (not type checking or linking).")
